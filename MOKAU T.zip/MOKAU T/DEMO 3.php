<!DOCTYPE.html>
<html>
	<head>
		<title></title>
	</head>
			<body>
				<form action="DEMO 3.php" method="GET">
				
					<p>firstname</p>
					<input type="text" name="firstname" placeholder="firstname">
					<p>secondname</p>
					<input type="text" name="secondname" placeholder="secondname">
					<p>age</p>
					<input type="text" name="age" placeholder="age">
					<input type="submit" >
				</form>



			<?php
			$name=$_GET["firstname"];
				echo($name);
			$students=array("tsepang","tlotliso","motlalepula","thabo","tumelo");
				echo($students[0]);	

		function multiplier($a,$b){
			$c=$a*$b;
			return $c;
		};
		$d=multiplier(3,4);
		echo($d);	
	



				

			?>

			
			
			</body>
			
</html>